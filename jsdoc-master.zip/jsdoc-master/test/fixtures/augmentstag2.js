// Test for @augments/@extends tags that refer to undefined symbols
/**
 * @constructor
 * @extends UndocumentedThing
 */
function Qux() {}
