


1. Application Name and Version
======================================

ONVIF Test Tool 1412 SR1


2. System Requirements
======================================

	1. Windows 7 / Windows 8  

	2. .NET Framework 4.5
	



3. Installation Instructions:
======================================

	1. Please read 'ONVIF_Device_TestTool_Installation_Guide.docx' file for the detailed instructions.

	2. Run setup.exe and follow installer instructions.
	
	3. After installation complete, go to Start->Program->ONVIF menu and run aplication.

	4. Please read 'ONVIF_Test_Tool_Release_Notes_vTUVW.1412SR1.pdf' file for the description of this versions' contents.

	5. It would be highly appreciated if you provide your feedback (found bugs) to ONVIF workgroups


On Profile S related items to Maintenance WG: oonvif_tsc_wgmaintenance@mail.onvif.org

On Profile G related items to Maintenance WG: oonvif_tsc_wgmaintenance@mail.onvif.org

On maintenance related items to Maintenance WG: onvif_tsc_wgmaintenance@mail.onvif.org

On Advanced Securily related items to Security Test WG: onvif_tsc_wgsecuritytest@mail.onvif.org

On Profile A related items to Profile A WG: onvif_tsc_wgprofile_a@mail.onvif.org

On Profile Q related items to Profile Q WG: onvif_tsc_wgprofile_q@mail.onvif.org


