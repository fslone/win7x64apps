/**
 * @overview This is a file doclet.
 * @copyright Michael Mathews 2011
 */

function ignoreMe() {
}