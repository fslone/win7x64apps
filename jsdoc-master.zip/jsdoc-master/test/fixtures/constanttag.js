/** @constant */
var FOO = 1;

/** @const BAR */

/** @const {string} BAZ */
