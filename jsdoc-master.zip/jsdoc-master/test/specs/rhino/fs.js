/*global describe: true */
describe("fs", function() {
	// TODO
});