Classify('TextBlock', {
    
    /**
        Document your constructor function here.
        @constructs TextBlock
        @classdesc Describe your class here
        @param {object} opts
        @throws MissingNode
     */
    construct: function(node, opts) {
    },
    
    /**
        Document your method here.
        @memberof TextBlock#
     */
    align: function() {
    }
});